<template>
    <div class="h-box-start">
        <div class="v-box">
                <div class="itemhuati">
                    <p>宋都南郡北区4-2-1908</p>
                    <span>进行中的话题</span>
                    <span>3</span>
                </div>
                <div class="item1">
                    <p>宋都南郡北区4-2-1908</p>
                    <span>进行中的话题</span>
                    <span>4</span>
                </div>
                <div class="item1">
                    <p>宋都南郡北区4-2-1908</p>
                    <span>进行中的话题</span>
                    <span>5</span>
                </div>
                <div class="item1">
                    <p>宋都南郡北区4-2-1908</p>
                    <span>进行中的话题</span>
                    <span>6</span>
                </div>
                <div class="item1">
                    <p>宋都南郡北区4-2-1908</p>
                    <span>进行中的话题</span>
                    <span>7</span>
                </div>
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style type="text/css">
@import "./Base.css";

.itemhuati{
  flex: 0 0 50%;
  border-right:1px solid #C8C8C8;
  border-bottom:2px solid #C8C8C8;
}

</style>


