<template>
    <div class="h-box-start">
        <div class="v-box">
                <div class="itemhuati-line">
                    <p>卫浴工人为什么没进行安装？</p>
                    <span>好图-刘勇  18/04/25</span>
                    <p>
                      <span >宋都南郡北区4-2-1908</span>
                      <span class="toright">安华</span>
                    </p>
                </div>
                <div class="itemhuati-line">
                    <p>瓷砖可以送货了</p>
                    <span>好图-刘勇  18/04/25</span>
                    <p>
                      <span >宋都南郡北区4-2-1908</span>
                      <span class="toright">安华</span>
                    </p>
                </div> 
                <div class="itemhuati-line">
                    <p>卫浴工人为什么没进行安装？</p>
                    <span>好图-刘勇  18/04/25</span>
                    <p>
                      <span >宋都南郡北区4-2-1908</span>
                      <span class="toright">安华</span>
                    </p>
                </div>                 
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style type="text/css">
@import "./Base.css";

.itemhuati-line{
  flex: 0 0 80%;
  border-bottom:2px solid #C8C8C8;
}
.toright{
  float:right;
}
</style>

